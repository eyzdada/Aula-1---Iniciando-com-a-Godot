extends Node2D

# variável para controlar as vidas
var vidas: int = 3
